package com.techm.ms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;

import com.techm.ms.model.User;

@Service("userService")
public class UserServiceImpl implements UserService {

private static List<User> users;
	
private static final AtomicLong counter = new AtomicLong();
	static {
		users= populateDummyUsers();
	}
	
	//User user;
	@Override
	public User createUser(String name, int age, int accountID) {
		long userID= counter.incrementAndGet();
		users.add(new User(counter.incrementAndGet(),name, age, accountID));
		return users.get((int) userID);
	}
	
	public List<User> findAllUsers(){
		return users;
	}
	
	private static List<User> populateDummyUsers(){
		List<User> user = new ArrayList<User>();
		user.add(new User(counter.incrementAndGet(),"User1", 24, 1));
		user.add(new User(counter.incrementAndGet(),"User2", 25, 2));
		user.add(new User(counter.incrementAndGet(),"User3", 26, 3));
		return user;
	}

	@Override
	public User getUser(int userID) {
		for(User user: users){
			if(user.getId() == userID){
				return user;
			}
		}
		return null;
	}

	
}
