package com.techm.ms.service;

import java.util.List;

import com.techm.ms.model.User;

public interface UserService {
 User createUser(String name, int age, int accountID);
 List<User> findAllUsers();
 User getUser(int userID);
}
